DROP TABLE guestbook CASCADE IF EXISTS;
CREATE TABLE guestbook (
    "id" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "email" VARCHAR(32) NOT NULL DEFAULT 'noemail@test.com',
    "comment" TEXT NULL,
    "created" DATETIME NOT NULL
);
INSERT INTO guestbook ("email", "comment", "created") VALUES
    ('ralph.schindler@zend.com',
    'Hello! Hope you enjoy this sample zf application!',
    NOW());
INSERT INTO guestbook ("email", "comment", "created") VALUES
    ('foo@bar.com',
    'Baz baz baz, baz baz Baz baz baz - baz baz baz.',
    NOW());
