<?php
return array(
    'db' => array(
        'username' => 'dba',
        'password' => 'goalie',
    ),
);